package org.example;

public class PoundCalculator {

    public static Double converter(Double kg) {
        // ritorna il valore dei kg inseriti in pound
        // 1 kg -> 2.20462000 pound
        return kg*(2.20462000);
    }

}
